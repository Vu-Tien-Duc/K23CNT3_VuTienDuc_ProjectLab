<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registration Form</title>
</head>
<body>
    <h1>#Registration Form</h1>
    <form method="POST" action="<?php echo e(route('signup.submit')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="id">User ID:</label>
            <input type="text" name="id" id="id" class="form-control" value="<?php echo e(old('id')); ?>">
            <?php $__errorArgs = ['id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" class="form-control">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name')); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="address">Address:</label>
            <input type="text" name="address" id="address" class="form-control" value="<?php echo e(old('address')); ?>">
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Chỉnh sửa thành dropdown list cho quốc gia -->
        <div class="form-group">
            <label for="country">Country:</label>
            <select name="country" id="country" class="form-control">
                <option value="">Please select a country</option>
                <option value="VIETNAM" <?php echo e(old('country') == 'VIETNAM' ? 'selected' : ''); ?>>Vietnam</option>
                <option value="US" <?php echo e(old('country') == 'US' ? 'selected' : ''); ?>>United States</option>
                <option value="UK" <?php echo e(old('country') == 'UK' ? 'selected' : ''); ?>>United Kingdom</option>
                <option value="CHINA" <?php echo e(old('country') == 'CHINA' ? 'selected' : ''); ?>>China</option>
                <option value="JAPAN" <?php echo e(old('country') == 'JAPAN' ? 'selected' : ''); ?>>Japan</option>
                <option value="INDONESIA" <?php echo e(old('country') == 'INDONESIA' ? 'selected' : ''); ?>>Indonesia</option>
                <option value="PHILIPIN" <?php echo e(old('country') == 'PHILIPIN' ? 'selected' : ''); ?>>Philippines</option>
            </select>
            <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="zipcode">ZIP Code:</label>
            <input type="number" name="zipcode" id="zipcode" class="form-control" value="<?php echo e(old('zipcode')); ?>">
            <?php $__errorArgs = ['zipcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email')); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label>Sex:</label>
            <label>
                <input type="radio" name="sex" value="Male" <?php echo e(old('sex') == 'Male' ? 'checked' : ''); ?>> Maleê
            </label>
            <label>
                <input type="radio" name="sex" value="Female" <?php echo e(old('sex') == 'Female' ? 'checked' : ''); ?>> Female
            </label>
            <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="language">Language:</label>
            <label>
                <input type="checkbox" name="language[]" value="English" <?php echo e(in_array('English', old('language', [])) ? 'checked' : ''); ?>> English
            </label>
            <label>
                <input type="checkbox" name="language[]" value="Non English" <?php echo e(in_array('Non English', old('language', [])) ? 'checked' : ''); ?>> Non English
            </label>
            <?php $__errorArgs = ['language'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="about">About:</label>
            <input type="text" name="about" id="about" class="form-control" value="<?php echo e(old('about')); ?>">
            <?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Submit</button>
    </form>
</body>
</html>
<?php /**PATH D:\K23CNT3-VuTienDuc-Project1\K23CNT3_VuTienDuc_ProjectLab\lesson04\vtd-lesson04\resources\views/signup.blade.php ENDPATH**/ ?>