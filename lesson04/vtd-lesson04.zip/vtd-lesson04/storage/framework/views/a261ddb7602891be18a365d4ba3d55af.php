<form method="POST" action="<?php echo e(route('login.submit')); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-group">
    <label for="email">Email:</label>
    <input type="email" name="email" id="email" class="form-control">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
    <label for="password">Password:</label>
    <input type="password" class="form-control"
    name="password" id="password" value="12346a@">
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <button type="submit" class="btn btn-primary mt-3">Submit</button>
    </form><?php /**PATH D:\K23CNT3-VuTienDuc-Project1\K23CNT3_VuTienDuc_ProjectLab\lesson04\vtd-lesson04\resources\views/login.blade.php ENDPATH**/ ?>