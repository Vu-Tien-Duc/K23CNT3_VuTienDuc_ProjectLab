<style>
    h1{
        text-align: center;
        font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
        height: 50px;
        line-height: 50px;
        color: red;
        background-color: chartreuse;
    }
    h2{
        text-align: center;
        font-family: 'Times New Roman', Times, serif;
        font-style: italic;
        font-weight: bold;
        height: 50px;
        line-height: 50px;
        color: red;

    }
    ul{
        margin-left: 15px;
    }
</style>
<div>
    <!-- The whole future lies in uncertainty: live immediately. - Seneca -->
    <h1>This is Header component</h1>
    <h2>Welcome to,<?php echo e($name); ?></h2>
    
    <h3>Fruits are: </h3>
    <ul>
        <?php $__currentLoopData = $fruits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>  <?php echo e($item); ?>  </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><?php /**PATH D:\K23CNT3-VuTienDuc-Project1\K23CNT3_VuTienDuc_ProjectLab\lesson02\vtd-lesson02\resources\views/components/header.blade.php ENDPATH**/ ?>