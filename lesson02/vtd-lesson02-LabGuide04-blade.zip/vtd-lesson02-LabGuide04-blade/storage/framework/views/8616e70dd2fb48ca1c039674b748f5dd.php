<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>#Loops: Cấu trúc lặp [foreach, forelse, while,...]</h1>
    <hr>

     /* Hiển Thị Giá Trị Của $i Từ 1 Đến 4 */
    <?php for( $i = 1 ; $i < 5 ; $i++ ): ?>
        <p> Giá Trị Của I là: <?php echo e($i); ?>

    <?php endfor; ?>
    <hr>

    <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p> This is Name: <?php echo e($item); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <hr>

    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li> <?php echo e($user); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p> no uses</P>
    <?php endif; ?>

    <?php 
    $i = 0;
    ?>

    <?php while( $i < 5 ): ?>
        <p?> Curent @$i = <?php echo e($i); ?> </p>
        <?php
            $i++;
        ?>
    <?php endwhile; ?>
    <hr>

    <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($loop->first): ?>
            <?php continue; ?>
        <?php endif; ?>
        <?php if($loop->last): ?>
            <p> This is the last iteration.
        <?php endif; ?>
        <li><?php echo e($item); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH D:\K23CNT3-VuTienDuc-Project1\K23CNT3_VuTienDuc_ProjectLab\lesson02\vtd-lesson02\resources\views/view-3.blade.php ENDPATH**/ ?>