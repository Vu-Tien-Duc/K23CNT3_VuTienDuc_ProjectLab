<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>#If Statements</h1>
    <hr>
    
        <pre>
            @if(count($array)===1)
                I Have one element!
            @elseif(count($array)>1)
                I have multiple element!
            @else
                I Don't Have any element!
            @endif
        </pre>

        
        <h2>Mảng {{$array}} :</h2>
            <?php if(count($array) === 1): ?>
                I have one element!
            <?php elseif(count($array) > 1): ?>
                I have multiple element!
            <?php else: ?>
                I don't have
            <?php endif; ?>
</body>
</html><?php /**PATH D:\K23CNT3-VuTienDuc-Project1\K23CNT3_VuTienDuc_ProjectLab\lesson02\vtd-lesson02\resources\views/view-2.blade.php ENDPATH**/ ?>