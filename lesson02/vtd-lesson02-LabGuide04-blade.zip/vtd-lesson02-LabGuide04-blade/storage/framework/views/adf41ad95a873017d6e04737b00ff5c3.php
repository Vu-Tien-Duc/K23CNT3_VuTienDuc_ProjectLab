<!-- master.blade.php -->
<?php echo $__env->make('_layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Kết nối phần header -->

<body>
    <?php echo $__env->make('_layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Kết nối phần navbar -->
    <div class="container-fluid">
        <div class="row">
            <?php echo $__env->make('_layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Kết nối phần sidebar -->

            <!-- Nội dung chính của trang sẽ được thay thế ở đây -->
            <div class="col">
                <?php echo $__env->yieldContent('content'); ?> <!-- Phần nội dung thay đổi động -->
            </div>
        </div>
    </div>

    <?php echo $__env->make('_layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Kết nối phần footer -->
</body>
</html>
<?php /**PATH D:\K23CNT3-VuTienDuc-Project1\K23CNT3_VuTienDuc_ProjectLab\lesson02\vtd-lesson02\resources\views/_layouts/master.blade.php ENDPATH**/ ?>