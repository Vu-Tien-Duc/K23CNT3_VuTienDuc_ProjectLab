<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Tạo view đơn giản </title>
<style>
    h1{
        text-align: center;
        background-color: #fff;
        text-shadow: 2px 2px 20px black;
    }
</style>
</head>
<body>
    <h1>Tạo view đơn giản</h1>
    <hr>
    <h2>Hiển thị dữ liệu bằng ngôn ngữ blade: <?php echo e($name); ?></h2>
</body>
</html><?php /**PATH D:\K23CNT3-VuTienDuc-Project1\K23CNT3_VuTienDuc_ProjectLab\lesson02\vtd-lesson02\resources\views/view-1.blade.php ENDPATH**/ ?>