
<?php $__env->startSection('title','Contact Us'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
<div class="col-12">
<h1>Contact Us Page Content</h1>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\K23CNT3-VuTienDuc-Project1\K23CNT3_VuTienDuc_ProjectLab\lesson02\vtd-lesson02\resources\views/contact.blade.php ENDPATH**/ ?>