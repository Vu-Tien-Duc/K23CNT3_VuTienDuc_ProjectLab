@extends('_layouts.master')
@section('title','Home index')
@section('content')
<div class="container">
<div class="row">
<div class="col-12">
<h1>Home Page Content</h1>
</div>
</div>
</div>
@endsection
