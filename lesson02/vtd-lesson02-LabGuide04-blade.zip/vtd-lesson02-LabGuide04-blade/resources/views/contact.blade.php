@extends('_layouts.master')
@section('title','Contact Us')
@section('content')
<div class="container">
<div class="row">
<div class="col-12">
<h1>Contact Us Page Content</h1>
</div>
</div>
</div>
@endsection