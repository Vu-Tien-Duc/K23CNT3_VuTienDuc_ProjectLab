

@extends('_layouts.master') <!--  là cú pháp Blade được sử dụng để kế thừa một layout (giao diện bố cục) chính từ tệp _layouts.master.  -->
@section('title','About Us')
@section('content')
<div class="container">
<div class="row">
<div class="col-12">
<h1>About Us Page Content</h1>
</div>
</div>
</div>
@endsection